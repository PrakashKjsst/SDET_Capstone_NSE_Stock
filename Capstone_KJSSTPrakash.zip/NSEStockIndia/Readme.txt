Steps 

1- import Java case study project as Maven project in IDE of your choice (intelliJ Idea . VS code or eclipse )

2 - Build Maven project by running mvn clean install command 

3 - Above command will import all required project dependecy 

4- Right Click on testng file and run as testng suite . this will execute the scripts parallelly in chrome, Edge and firefox browser