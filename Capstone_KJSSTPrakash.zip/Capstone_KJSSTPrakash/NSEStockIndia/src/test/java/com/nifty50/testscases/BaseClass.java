package com.nifty50.testscases;
import Utilities.Log;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class BaseClass {
	WebDriver driver;
	@BeforeMethod
	@Parameters({"Browser","URL"})
	public void Setup(String Browser,String url) throws InterruptedException {

		Log.info("Setting up Browser ");
		if(Browser.equalsIgnoreCase("chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver(options);	
		}
		else if(Browser.equalsIgnoreCase("edge")) {
			EdgeOptions options = new EdgeOptions();
			options.addArguments("--remote-allow-origins=*");
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver(options);
		}
		else if(Browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
		}
		
		driver.get(url);
		driver.manage().window().maximize();
        Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
	}
	@AfterMethod
	public void tearDown() {
		Log.info("Browser session closed");
		driver.quit();
	}
	
	public void captureScreenshot(WebDriver driver,String tname)throws IOException {

		TakesScreenshot screenShot =(TakesScreenshot)driver;
		File source=screenShot.getScreenshotAs(OutputType.FILE);
		File target=new File(System.getProperty("user.dir")+"/Screenshot/"+tname+".png");
		FileUtils.copyFile(source, target);
		Log.info("Screenshot captured");
	}
	

}
